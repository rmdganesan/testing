name 'yum-mysql-community'
maintainer 'Chef Software, Inc'
maintainer_email 'Sean OMeara <someara@getchef.com>'
license 'Apache 2.0'
description 'Installs/Configures yum-mysql-community'
version '0.1.8'

depends 'yum', '>= 3.0'
