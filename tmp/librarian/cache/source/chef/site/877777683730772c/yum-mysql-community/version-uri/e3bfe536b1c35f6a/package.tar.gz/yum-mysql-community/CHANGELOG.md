yum-mysql-community Cookbook CHANGELOG
======================
This file is used to list changes made in each version of the yum-centos cookbook.

v0.1.4 (2014-06-13)
-------------------
- updating url to keys in cookbook attributes


v0.1.2 (2014-06-11)
-------------------
#1 - Move files/mysql_pubkey.asc to files/default/mysql_pubkey.asc


v0.1.0 (2014-04-30)
-------------------
Initial release


v0.3.6 (2014-04-09)
-------------------
- [COOK-4509] add RHEL7 support to yum-mysql-community cookbook


v0.3.4 (2014-02-19)
-------------------
COOK-4353 - Fixing typo in readme


v0.3.2 (2014-02-13)
-------------------
Updating README to explain the 'managed' parameter


v0.3.0 (2014-02-12)
-------------------
[COOK-4292] - Do not manage secondary repos by default


v0.2.0
------
Adding Amazon Linux support


v0.1.6
------
Fixing up attribute values for EL6


v0.1.4
------
Adding CHANGELOG.md


v0.1.0
------
initial release
