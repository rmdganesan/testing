## v0.100.6:

* [COOK-2148] - `aws_ebs_volume` attach action saves nil `volume_id`
  in node

## v0.100.4:

* Support why-run mode in LWRPs
* [COOK-1836] - make `aws_elastic_lb` idempotent

## v0.100.2:

* [COOK-1568] - switch to chef_gem resource
* [COOK-1426] - declare default actions for LWRPs

## v0.100.0:

* [COOK-1221] - convert node attribute accessors to strings
* [COOK-1195] - manipulate AWS resource tags (instances, volumes,
  snapshots
* [COOK-627] - add aws_elb (elastic load balancer) LWRP
