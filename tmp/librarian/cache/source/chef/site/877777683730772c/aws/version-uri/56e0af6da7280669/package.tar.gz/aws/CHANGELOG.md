## v0.100.0:

* [COOK-1221] - convert node attribute accessors to strings
* [COOK-1195] - manipulate AWS resource tags (instances, volumes,
  snapshots
* [COOK-627] - add aws_elb (elastic load balancer) LWRP
