default['application_php']['cakephp']['version'] = '2.3.0'
default['application_php']['cakephp']['install_dir'] = '/opt/cakephp'
